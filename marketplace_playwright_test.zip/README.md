# Syncro Test Automation
#### Required Tools
* [Playwright](https://playwright.dev/ "Playwright")
* [VS Code](https://code.visualstudio.com/ "VS Code")
* [PyTest](https://docs.pytest.org/ "PyTest")
* [Python](https://www.python.org/ "Python")
 
 
